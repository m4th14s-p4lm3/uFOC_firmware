/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f3xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

void HAL_TIM_MspPostInit(TIM_HandleTypeDef *htim);

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define INLA_Pin GPIO_PIN_0
#define INLA_GPIO_Port GPIOF
#define ADC_IN1_sense_c_Pin GPIO_PIN_0
#define ADC_IN1_sense_c_GPIO_Port GPIOA
#define ADC1_IN2_sense_b_Pin GPIO_PIN_1
#define ADC1_IN2_sense_b_GPIO_Port GPIOA
#define ADC1_IN3_sense_a_Pin GPIO_PIN_2
#define ADC1_IN3_sense_a_GPIO_Port GPIOA
#define DRIVER_CS_Pin GPIO_PIN_4
#define DRIVER_CS_GPIO_Port GPIOA
#define ENCODER_CS_Pin GPIO_PIN_5
#define ENCODER_CS_GPIO_Port GPIOA
#define IMU_CS_Pin GPIO_PIN_6
#define IMU_CS_GPIO_Port GPIOA
#define INLC_Pin GPIO_PIN_7
#define INLC_GPIO_Port GPIOA
#define INLB_Pin GPIO_PIN_0
#define INLB_GPIO_Port GPIOB
#define INHC_Pin GPIO_PIN_8
#define INHC_GPIO_Port GPIOA
#define INHB_Pin GPIO_PIN_9
#define INHB_GPIO_Port GPIOA
#define INHA_Pin GPIO_PIN_10
#define INHA_GPIO_Port GPIOA

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
