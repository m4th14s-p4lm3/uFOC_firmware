#include "stm32f3xx_hal.h"
#include <math.h>

#define DRV8316_REG_PWM_CTRL 0x02

extern TIM_HandleTypeDef htim1;
extern  ADC_HandleTypeDef hadc1;
extern SPI_HandleTypeDef hspi3;


uint16_t read_adc_channel(ADC_HandleTypeDef *hadc, uint32_t channel)
{
    ADC_ChannelConfTypeDef sConfig = {0};
    sConfig.Channel = channel;
    sConfig.Rank = ADC_REGULAR_RANK_1;
    sConfig.SamplingTime = ADC_SAMPLETIME_61CYCLES_5;
    
    HAL_ADC_ConfigChannel(hadc, &sConfig);
    
    HAL_ADC_Start(hadc);
    HAL_ADC_PollForConversion(hadc, 10);
    uint16_t v = (uint16_t)HAL_ADC_GetValue(hadc);
    HAL_ADC_Stop(hadc);
    
    return v;
}

void pwm_init(){
    // Start PWM outputs
    HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1);
    HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_2);
    HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_3);

    // Start complementary outputs (CHxN)
    HAL_TIMEx_PWMN_Start(&htim1, TIM_CHANNEL_1);
    HAL_TIMEx_PWMN_Start(&htim1, TIM_CHANNEL_2);
    HAL_TIMEx_PWMN_Start(&htim1, TIM_CHANNEL_3);

    TIM1->CCR4 = TIM1->ARR / 2; 
}

void pwm_set(float du, float dv, float dw)
{
  // C B A
  // Values float du, float dv, float dw must be between 0 and 1 
  // these values represent percentage of PWM, the real max PWM value
  // is automaticly handled by ARR variable

  uint32_t ARR = __HAL_TIM_GET_AUTORELOAD(&htim1); // MAX PWM VALUE

  if (du < 0) du = 0; if (du > 1) du = 1;
  if (dv < 0) dv = 0; if (dv > 1) dv = 1;
  if (dw < 0) dw = 0; if (dw > 1) dw = 1;

  __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, (uint32_t)(du * ARR)); // INHC
  __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_2, (uint32_t)(dv * ARR)); // INHB
  __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_3, (uint32_t)(dw * ARR)); // INHA
}

void open_loop(){
  float theta = 0.0f;

  // open-loop parametry
  const float Ts = 0.0001f;
  const float fe = 100.0f;            // frekvence [Hz] 
  const float omega = 2.0f * (float)M_PI * fe;
  const float m = 0.80f;             // modulace (0..~0.9),

  while (1)
  {
    theta += omega * Ts;
    if (theta > 2.0f * (float)M_PI) theta -= 2.0f * (float)M_PI;

    float su = sinf(theta);
    float sv = sinf(theta - 2.0f*(float)M_PI/3.0f);
    float sw = sinf(theta - 4.0f*(float)M_PI/3.0f);

    // map -1..1 -> 0..1 s modulací m
    float du = 0.5f + 0.5f * m * su;
    float dv = 0.5f + 0.5f * m * sv;
    float dw = 0.5f + 0.5f * m * sw;

    pwm_set(du, dv, dw);

    for (volatile int i=0; i< (int)(SystemCoreClock * Ts / 10); i++) { __NOP(); }
  }
}






// Základní funkce pro odeslání a přijetí 16 bitů
uint16_t drv8316_spi_transfer(uint16_t tx_data) {
    uint8_t tx_buf[2];
    uint8_t rx_buf[2];
    
    // Rozdělení 16bit slova na dva byty
    tx_buf[0] = (tx_data >> 8) & 0xFF; // Horní byte
    tx_buf[1] = tx_data & 0xFF;        // Dolní byte
    
    // Zatažení DRIVER_CS do logické nuly (aktivace driveru)
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_RESET); 
    
    // Samotný přesun dat
    HAL_SPI_TransmitReceive(&hspi3, tx_buf, rx_buf, 2, HAL_MAX_DELAY);
    
    // Uvolnění DRIVER_CS (deaktivace)
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_SET); 
    
    // Spojení přijatých bytů zpět do 16bit čísla
    return (rx_buf[0] << 8) | rx_buf[1];
}

// Zápis do registru
void drv8316_write_reg(uint8_t reg_addr, uint8_t data) {
    // Bit 15 = 0 (Write), Bity 14-9 = Adresa, Bit 8 = 0, Bity 7-0 = Data
    uint16_t tx_word = ((reg_addr & 0x3F) << 9) | data;
    drv8316_spi_transfer(tx_word);
}

// Čtení z registru
uint8_t drv8316_read_reg(uint8_t reg_addr) {
    // Bit 15 = 1 (Read), Bity 14-9 = Adresa, Bity 8-0 = 0
    uint16_t tx_word = (1 << 15) | ((reg_addr & 0x3F) << 9);
    uint16_t rx_word = drv8316_spi_transfer(tx_word);
    return (uint8_t)(rx_word & 0xFF);
}

// Hlavní inicializace
void drv8316_init(void) {
    // 1. Přečtení aktuální hodnoty Control Register 2
    uint8_t reg_val = drv8316_read_reg(DRV8316_REG_CTRL2);
    
    // 2. Vymazání bitů 2 a 1 pro PWM_MODE (binárně 0b110, hex 0x06)
    reg_val &= ~(0x06);
    
    // 3. Zápis hodnoty 2h (3x PWM mode) na pozici bitů 2 a 1
    // Hodnota 2 posunutá o 1 bit doleva (2 << 1)
    reg_val |= (0x02 << 1);
    
    // 4. Zápis upravené hodnoty zpět do driveru
    drv8316_write_reg(DRV8316_REG_CTRL2, reg_val);
}